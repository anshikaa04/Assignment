package MA104_assignment;

public class Assignment {
	int ms1;
	int ms2;
	Assignment(int ms1,int ms2) {
		this.ms1=ms1;
		this.ms2=ms2;
	}
	int scaling_assingment(int ms1,int ms2) {
		int avg=(ms1+ms2)/2;
		return avg;
	}
}
