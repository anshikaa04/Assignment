package MA104_assignment;

public interface Quiz {
	public int best(int q1,int q2,int q3);
}
