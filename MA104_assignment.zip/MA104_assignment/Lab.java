package MA104_assignment;

public interface Lab {
	public int avg(int l1,int l2,int l3,int l4);
}
